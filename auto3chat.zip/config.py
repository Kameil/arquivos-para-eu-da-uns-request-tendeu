# obrigatorios
user_token = ""
catch_id = ""
prefix = "!/"

# opcionais 
catch_id2 = ""
catch_id3 = ""
catch_id4 = ""
catch_id5 = ""
catch_id6 = ""

ping = "" # id do usuario a ser pingado quando captcha aparecer